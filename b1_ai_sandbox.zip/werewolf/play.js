// ==================== 游戏配置 ====================
const GAME_CONFIG = {
    playerCounts: {
        6: { wolves: 2, gods: 2, civilians: 2 },
        8: { wolves: 2, gods: 3, civilians: 3 },
        10: { wolves: 3, gods: 4, civilians: 3 },
        12: { wolves: 4, gods: 4, civilians: 4 }
    },
    roleNames: {
        wolves: ['狼人'],
        gods: ['预言家', '女巫', '猎人', '守卫'],
        civilians: ['平民']
    }
};

// ==================== 游戏状态 ====================
let gameState = {
    playerCount: 8,
    aiModel: 'llama3.1:latest',
    playerName: '你',
    intervalSeconds: 3,
    randomOrder: true
};

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    initUI();
    loadSettings();
});

function initUI() {
    // 玩家数量选择
    const countBtns = document.querySelectorAll('.count-btn');
    countBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            countBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            gameState.playerCount = parseInt(btn.dataset.count);
            updateRolePreview();
        });
    });

    // 开始游戏按钮
    document.getElementById('start-btn').addEventListener('click', startGame);

    // 设置变化
    document.getElementById('ai-model').addEventListener('change', (e) => {
        gameState.aiModel = e.target.value;
    });

    document.getElementById('player-name').addEventListener('input', (e) => {
        gameState.playerName = e.target.value.trim() || '你';
    });

    document.getElementById('interval-seconds').addEventListener('change', (e) => {
        gameState.intervalSeconds = parseInt(e.target.value);
    });

    document.getElementById('random-order').addEventListener('change', (e) => {
        gameState.randomOrder = e.target.checked;
    });
}

function updateRolePreview() {
    const config = GAME_CONFIG.playerCounts[gameState.playerCount];
    const preview = document.getElementById('role-preview-text');
    preview.textContent = `${gameState.playerCount}人局：${config.wolves}狼人 + ${config.gods}神职 + ${config.civilians}平民`;
}

function loadSettings() {
    const saved = localStorage.getItem('werewolf_play_settings');
    if (saved) {
        const settings = JSON.parse(saved);
        Object.assign(gameState, settings);

        // 恢复UI状态
        document.querySelectorAll('.count-btn').forEach(btn => {
            if (parseInt(btn.dataset.count) === gameState.playerCount) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        document.getElementById('ai-model').value = gameState.aiModel;
        document.getElementById('player-name').value = gameState.playerName;
        document.getElementById('interval-seconds').value = gameState.intervalSeconds;
        document.getElementById('random-order').checked = gameState.randomOrder;

        updateRolePreview();
    }
}

function saveSettings() {
    localStorage.setItem('werewolf_play_settings', JSON.stringify(gameState));
}

function startGame() {
    saveSettings();

    // 保存游戏配置到sessionStorage
    sessionStorage.setItem('werewolf_game_config', JSON.stringify({
        playerCount: gameState.playerCount,
        aiModel: gameState.aiModel,
        playerName: gameState.playerName,
        intervalSeconds: gameState.intervalSeconds,
        randomOrder: gameState.randomOrder
    }));

    // 跳转到游戏页面
    window.location.href = 'game.html';
}
