// ==================== 狼人杀游戏逻辑 - 玩家参与模式 ====================
// 模型和API函数已在 shared.js 中定义

const PHASE = {
    SETUP: 'setup',
    NIGHT: 'night',
    DAY_ANNOUNCE: 'day_announce',
    DAY_SPEAK: 'day_speak',
    DAY_VOTE: 'day_vote',
    GAME_END: 'game_end'
};

const ROLE_ICONS = {
    '预言家': 'fa-eye',
    '女巫': 'fa-flask',
    '猎人': 'fa-crosshairs',
    '守卫': 'fa-shield-alt',
    '平民': 'fa-user',
    '狼人': 'fa-skull',
    '白狼王': 'fa-crown',
    '狼美人': 'fa-heart'
};

// ==================== 游戏状态 ====================
let gameState = {
    players: [],
    messages: [],
    wolfMessages: [],  // 狼人团队聊天记录
    phase: PHASE.SETUP,
    day: 0,
    currentSpeakerIndex: 0,
    speakingOrder: [],
    votes: {},
    deadPlayers: [],
    nightActions: {},
    userPlayer: null,
    isNightActionComplete: false,
    isRunning: false,
    isPaused: false,
    waitingForUser: false,
    waitingForUserVote: false,
    wolfTeamMessages: [],  // 狼人团队聊天
    waitingForWolfSpeak: false,
    waitingForWolfVote: false,
    resolveWolfSpeak: null,
    resolveWolfVote: null
};

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    loadGameConfig();
    initGame();
    initEventListeners();
});

function loadGameConfig() {
    try {
        const configStr = sessionStorage.getItem('werewolf_game_config');
        if (!configStr) {
            alert('游戏配置丢失，请重新开始');
            window.location.href = 'play.html';
            return;
        }

        const config = JSON.parse(configStr);
        // 初始化玩家
        initPlayers(config);
    } catch (e) {
        console.error('加载配置失败:', e);
        alert('游戏配置错误，请重新开始');
        window.location.href = 'play.html';
    }
}

function initPlayers(config) {
    const playerCount = config.playerCount;
    const roleConfig = getRoleConfig(playerCount);

    // 生成角色列表
    let roles = [];
    roles = roles.concat(Array(roleConfig.wolves).fill('狼人'));
    roles = roles.concat(Array(roleConfig.gods).fill(...getGodRoles(roleConfig.gods)));
    roles = roles.concat(Array(roleConfig.civilians).fill('平民'));

    // 洗牌
    roles = shuffleArray(roles);

    // 创建玩家
    gameState.players = [];

    // 先添加用户玩家
    const userRole = roles.pop();
    gameState.userPlayer = {
        id: 'user',
        name: config.playerName,
        role: userRole,
        alive: true,
        isUser: true
    };
    gameState.players.push(gameState.userPlayer);

    // 添加AI玩家
    const aiNames = getAINames(playerCount - 1);
    aiNames.forEach((name, index) => {
        const role = roles[index];
        gameState.players.push({
            id: `ai_${index}`,
            name: name,
            role: role,
            alive: true,
            isUser: false,
            model: config.aiModel,
            endpoint: 'http://localhost:11434/v1',
            apiKey: 'ollama'
        });
    });

    gameState.aiModel = config.aiModel;
    gameState.intervalSeconds = config.intervalSeconds;
    gameState.randomOrder = config.randomOrder;
}

function getRoleConfig(count) {
    const configs = {
        6: { wolves: 2, gods: 2, civilians: 2 },
        8: { wolves: 2, gods: 3, civilians: 3 },
        10: { wolves: 3, gods: 4, civilians: 3 },
        12: { wolves: 4, gods: 4, civilians: 4 }
    };
    return configs[count] || configs[8];
}

function getGodRoles(count) {
    const allGods = ['预言家', '女巫', '猎人', '守卫'];
    const selectedGods = [];
    for (let i = 0; i < count; i++) {
        selectedGods.push(allGods[i % allGods.length]);
    }
    return selectedGods;
}

function getAINames(count) {
    const names = [
        '小明', '小红', '小刚', '小芳', '小强', '小丽',
        '小华', '小梅', '小军', '小雨', '小亮', '小王'
    ];
    return names.slice(0, count);
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// ==================== 游戏初始化 ====================
function initGame() {
    gameState.isRunning = true;
    gameState.isPaused = false;
    renderPlayers();
    addMessage('system', '主持人', '游戏开始！你的身份是：' + gameState.userPlayer.role);

    // 显示身份提示
    showRoleNotification();

    updatePhaseDisplay();

    // 延迟开始夜晚阶段
    setTimeout(() => startNightPhase(), 2000);
}

function showRoleNotification() {
    // 3秒后显示身份确认
    setTimeout(() => {
        if (gameState.userPlayer.alive) {
            showRoleModal();
        }
    }, 3000);
}

function initEventListeners() {
    // 发言输入
    document.getElementById('message-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
    document.getElementById('send-btn').addEventListener('click', sendMessage);

    // 查看身份按钮
    document.getElementById('role-btn').addEventListener('click', showRoleModal);

    // 退出按钮
    document.getElementById('leave-btn').addEventListener('click', () => {
        if (confirm('确定要退出游戏吗？')) {
            window.location.href = 'play.html';
        }
    });

    // 弹窗关闭
    document.querySelectorAll('.modal .close').forEach(btn => {
        btn.addEventListener('click', closeAllModals);
    });
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeAllModals();
        });
    });

    // 夜间行动确认
    document.getElementById('night-confirm-btn').addEventListener('click', confirmNightAction);

    // 狼人团队消息
    document.getElementById('wolf-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendWolfMessage();
    });
    document.getElementById('wolf-send-btn').addEventListener('click', sendWolfMessage);

    // 游戏结束按钮
    document.getElementById('restart-btn').addEventListener('click', () => {
        window.location.href = 'play.html';
    });
    document.getElementById('home-btn').addEventListener('click', () => {
        window.location.href = 'werewolf.html';
    });
}

// ==================== 渲染 ====================
function renderPlayers() {
    const grid = document.getElementById('players-grid');
    const userRole = gameState.userPlayer.role;
    const userIsWolf = userRole === '狼人' || userRole === '白狼王' || userRole === '狼美人';

    grid.innerHTML = gameState.players.map(player => {
        // 根据用户身份决定显示什么图标
        let roleIcon = 'fa-user';  // 默认显示平民图标
        let isWolf = '';

        if (player.isUser) {
            // 自己显示真实角色图标
            roleIcon = ROLE_ICONS[player.role] || 'fa-user';
        } else if (userIsWolf) {
            // 用户是狼人，可以看到其他狼人队友
            if (player.role === '狼人' || player.role === '白狼王' || player.role === '狼美人') {
                roleIcon = ROLE_ICONS[player.role] || 'fa-skull';
                isWolf = 'is-wolf';
            }
        }
        // 非狼人用户看不到真实角色图标

        const isMe = player.isUser ? 'is-me' : '';
        const statusClass = player.alive ? '' : 'dead';

        return `
            <div class="player-card ${isMe} ${isWolf} ${statusClass}">
                <div class="player-name">
                    <i class="fas ${roleIcon}"></i>
                    ${escapeHtml(player.name)}
                </div>
                <div class="player-status">
                    ${player.alive ? '存活' : '已死亡'}
                </div>
            </div>
        `;
    }).join('');
}

function renderMessages() {
    const container = document.getElementById('chat-messages');
    container.innerHTML = gameState.messages.map(msg => {
        let msgClass = 'message';
        if (msg.type === 'system') msgClass += ' system';
        else if (msg.type === 'user') msgClass += ' user';
        else if (msg.type === 'wolf') msgClass += ' wolf';

        return `
            <div class="${msgClass}">
                <div class="message-sender">${escapeHtml(msg.sender)}</div>
                <div class="message-text">${escapeHtml(msg.text)}</div>
            </div>
        `;
    }).join('');

    container.scrollTop = container.scrollHeight;
}

function addMessage(type, sender, text) {
    gameState.messages.push({
        id: Date.now(),
        type,
        sender,
        text,
        time: new Date().toLocaleTimeString()
    });
    renderMessages();
}

function updatePhaseDisplay() {
    const phaseNames = {
        [PHASE.SETUP]: '等待开始',
        [PHASE.NIGHT]: '夜晚',
        [PHASE.DAY_ANNOUNCE]: '公布死亡',
        [PHASE.DAY_SPEAK]: '白天发言',
        [PHASE.DAY_VOTE]: '投票阶段',
        [PHASE.GAME_END]: '游戏结束'
    };

    document.getElementById('phase-display').textContent = phaseNames[gameState.phase];
    document.getElementById('day-display').textContent = `第${gameState.day}天`;
}

// ==================== 用户交互 ====================
function sendMessage() {
    const input = document.getElementById('message-input');
    const text = input.value.trim();
    if (!text) return;

    addMessage('user', gameState.userPlayer.name, text);
    input.value = '';

    // 继续游戏流程
    if (gameState.waitingForUser) {
        gameState.waitingForUser = false;
        gameState.currentSpeakerIndex++;
        setTimeout(handleDaySpeak, gameState.intervalSeconds * 1000);
    } else if (gameState.waitingForUserVote) {
        // 解析投票目标
        const target = gameState.players.find(p => p.alive && p.name === text);
        if (target && target.id !== gameState.userPlayer.id) {
            gameState.votes[gameState.userPlayer.id] = target.id;
            addMessage('system', '主持人', `${gameState.userPlayer.name} 投票给 ${target.name}`);
            gameState.waitingForUserVote = false;
            gameState.currentSpeakerIndex++;
            setTimeout(handleVote, gameState.intervalSeconds * 1000);
        } else {
            addMessage('system', '主持人', '无效的投票，请重新输入（输入玩家名字）');
        }
    }
}

// ==================== 夜晚阶段 ====================
async function startNightPhase() {
    if (!checkGameRunning()) return;

    gameState.phase = PHASE.NIGHT;
    gameState.nightActions = {
        wolfKill: null,
        witchSave: false,
        witchPoison: null,
        guardProtect: null,
        seerCheck: null
    };
    updatePhaseDisplay();

    addMessage('system', '主持人', '============== 天黑请闭眼 ==============');

    // 等待用户夜间行动
    if (gameState.userPlayer.alive) {
        await handleUserNightAction();
    }

    // AI夜间行动
    await handleAINightActions();

    // 进入白天
    setTimeout(showDayAnnounce, 1000);
}

async function handleUserNightAction() {
    return new Promise((resolve) => {
        const userRole = gameState.userPlayer.role;

        if (userRole === '狼人') {
            // 狼人选择杀人目标 - 在handleAINightActions中处理
            addMessage('system', '主持人', '你是狼人，请等待团队讨论...');
            setTimeout(() => resolve(), 1000);
        } else if (userRole === '预言家') {
            // 预言家查验身份 - 等待狼人杀人后再查验
            addMessage('system', '主持人', '你是预言家，请等待...');
            setTimeout(() => resolve(), 1000);
        } else if (userRole === '守卫') {
            // 守卫选择守护目标 - 等待狼人杀人后再守护
            addMessage('system', '主持人', '你是守卫，请等待...');
            setTimeout(() => resolve(), 1000);
        } else if (userRole === '女巫') {
            // 女巫阶段 - 等待狼人杀人后再决定
            addMessage('system', '主持人', '你是女巫，请等待狼人行动...');
            setTimeout(() => resolve(), 1000);
        } else {
            // 平民直接等待
            addMessage('system', '主持人', '你是平民，请等待天亮');
            setTimeout(() => resolve(), 1000);
        }
    });
}

function showNightActionModal(prompt, actionType) {
    const modal = document.getElementById('night-modal');
    const actions = document.getElementById('night-actions');
    const alivePlayers = gameState.players.filter(p => p.alive);

    let availableTargets = alivePlayers;
    if (actionType === 'wolf-kill') {
        availableTargets = alivePlayers.filter(p => p.role !== '狼人' && p.role !== '白狼王' && p.role !== '狼美人');
    } else if (actionType === 'seer-check') {
        availableTargets = alivePlayers.filter(p => p.id !== gameState.userPlayer.id);
    } else if (actionType === 'guard-protect') {
        availableTargets = alivePlayers;
    }

    document.getElementById('night-modal').querySelector('h2').innerHTML =
        `<i class="fas fa-moon"></i> ${prompt}`;

    actions.innerHTML = availableTargets.map(p => `
        <button class="night-action-btn" data-player-id="${p.id}" data-action="${actionType}">
            ${escapeHtml(p.name)}
        </button>
    `).join('');

    actions.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
            actions.querySelectorAll('button').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
        });
    });

    modal.classList.add('show');
}

function confirmNightAction() {
    const selected = document.querySelector('.night-action-btn.selected');
    if (!selected) {
        alert('请选择一个目标');
        return;
    }

    const playerId = selected.dataset.playerId;
    const actionType = selected.dataset.action;
    const target = gameState.players.find(p => p.id === playerId);

    switch (actionType) {
        case 'wolf-kill':
            gameState.nightActions.wolfKill = target;
            addMessage('wolf', '系统', `你选择杀死 ${target.name}`);
            break;
        case 'seer-check':
            gameState.nightActions.seerCheck = {
                target: target,
                isWolf: target.role === '狼人' || target.role === '白狼王' || target.role === '狼美人'
            };
            addMessage('system', '主持人', `${target.name} 是 ${target.role === '狼人' || target.role === '白狼王' || target.role === '狼美人' ? '狼人' : '好人'}`);
            break;
        case 'guard-protect':
            gameState.nightActions.guardProtect = target;
            addMessage('system', '主持人', `你选择守护 ${target.name}`);
            break;
    }

    closeAllModals();
    gameState.isNightActionComplete = true;

    if (gameState.resolveNightAction) {
        gameState.resolveNightAction();
    }
}

async function handleAINightActions() {
    const alive = gameState.players.filter(p => p.alive);
    const wolves = alive.filter(p => p.role === '狼人' || p.role === '白狼王' || p.role === '狼美人');
    const userIsWolf = (gameState.userPlayer.role === '狼人' || gameState.userPlayer.role === '白狼王' || gameState.userPlayer.role === '狼美人') && gameState.userPlayer.alive;

    // 狼人杀人
    if (!gameState.nightActions.wolfKill && wolves.length > 0) {
        const targets = alive.filter(p => p.role !== '狼人' && p.role !== '白狼王' && p.role !== '狼美人');

        if (targets.length > 0) {
            // 狼人团队讨论 - 包含用户
            const allWolves = [...wolves];
            const dayHistory = gameState.messages.slice(-20).map(m => `${m.sender}: ${m.text}`).join('\n');

            // 显示狼人团队聊天
            if (userIsWolf) {
                showWolfChatModal();
            }

            // 构建讨论顺序 - 用户在最后
            const aiWolves = wolves.filter(w => !w.isUser);
            const wolfOrder = [];

            // 先让AI狼人发言
            for (let i = 0; i < aiWolves.length; i++) {
                const wolf = aiWolves[i];
                wolfOrder.push({ id: wolf.id, name: wolf.name, isUser: false });
            }

            // 如果用户是狼人，添加用户到最后
            if (userIsWolf) {
                wolfOrder.push({ id: gameState.userPlayer.id, name: gameState.userPlayer.name, isUser: true });
            }

            let discussionLog = '';

            // 讨论阶段
            addWolfMessage('系统', '开始狼人团队讨论...');

            for (let i = 0; i < wolfOrder.length; i++) {
                const speaker = wolfOrder[i];

                if (speaker.isUser) {
                    // 用户发言 - 暂停等待用户输入
                    addWolfMessage('系统', `轮到你发言了...`);
                    gameState.waitingForWolfSpeak = true;
                    gameState.resolveWolfSpeak = null;

                    // 打开狼人聊天并等待
                    await new Promise(resolve => {
                        gameState.resolveWolfSpeak = resolve;
                    });
                } else {
                    // AI发言
                    const wolf = aiWolves.find(w => w.id === speaker.id);
                    const discussPrompt = `你是狼人${wolf.name}。你们狼人团队正在讨论要杀谁，请发表你的看法。

存活好人：${targets.map(t => t.name).join('、')}

【今天的公开讨论】（供你参考）
${dayHistory}

【狼人团队之前的讨论】
${discussionLog || '暂无'}

**注意：发言控制在30字以内，简短有力。最后说玩家名字。**`;

                    const response = await callPlayerAI(wolf, discussPrompt);
                    discussionLog += `\n${speaker.name}: ${response}`;
                    addWolfMessage(speaker.name, response);

                    await new Promise(resolve => setTimeout(resolve, gameState.intervalSeconds * 500));
                }
            }

            // 投票阶段
            addWolfMessage('系统', '讨论结束，开始投票...');

            const votes = {};

            for (let i = 0; i < wolfOrder.length; i++) {
                const speaker = wolfOrder[i];

                if (speaker.isUser) {
                    // 用户投票 - 暂停等待用户输入
                    gameState.waitingForWolfVote = true;
                    gameState.resolveWolfVote = null;

                    await new Promise(resolve => {
                        gameState.resolveWolfVote = resolve;
                    });
                } else {
                    // AI投票
                    const wolf = aiWolves.find(w => w.id === speaker.id);
                    const votePrompt = `你是狼人${wolf.name}。基于刚才的讨论，请投票决定要杀死的玩家。

存活好人：${targets.map(t => t.name).join('、')}

这是投票，直接说玩家名字，不要其他话。`;

                    const response = await callPlayerAI(wolf, votePrompt);
                    const targetName = parseName(response, targets.map(t => t.name));
                    votes[targetName] = (votes[targetName] || 0) + 1;
                    addWolfMessage(`${speaker.name}的投票`, targetName);
                }
            }

            // 统计票数
            let maxVotes = 0;
            let killTarget = targets[0];
            Object.entries(votes).forEach(([name, count]) => {
                if (count > maxVotes) {
                    maxVotes = count;
                    killTarget = targets.find(t => t.name === name);
                }
            });

            gameState.nightActions.wolfKill = killTarget || targets[0];
            addWolfMessage('系统', `最终决定杀 ${gameState.nightActions.wolfKill.name}`);
        }
    }

    // 女巫行动 - 使用用户选择或AI决策
    const witch = alive.find(p => p.role === '女巫');
    if (witch && gameState.nightActions.wolfKill) {
        // 女巫救人
        if (witch.isUser) {
            // 用户是女巫 - 等待用户决定
            addMessage('system', '主持人', `昨晚 ${gameState.nightActions.wolfKill.name} 被杀。你是女巫，是否使用解药？`);

            // 打开夜间行动模态框让用户选择
            showNightActionModal('女巫：是否救人？', 'witch-save');
            gameState.resolveNightAction = null;

            await new Promise(resolve => {
                gameState.resolveNightAction = resolve;
            });
        } else {
            // AI女巫
            const prompt = `你是女巫。昨晚 ${gameState.nightActions.wolfKill.name} 被杀。

是否使用解药救他？请回答"救"或"不救"。`;

            try {
                const response = await callPlayerAI(witch, prompt);
                if (response.includes('救')) {
                    gameState.nightActions.witchSave = true;
                }
            } catch (e) {
                // 随机
            }
        }
    }

    // 预言家查验
    const seer = alive.find(p => p.role === '预言家');
    if (seer) {
        if (seer.isUser) {
            // 用户是预言家 - 等待用户选择查验目标
            addMessage('system', '主持人', '你是预言家，请选择要查验的玩家');

            // 打开夜间行动模态框
            showNightActionModal('预言家：选择查验目标', 'seer-check');
            gameState.resolveNightAction = null;

            await new Promise(resolve => {
                gameState.resolveNightAction = resolve;
            });
        } else {
            // AI预言家
            const targets = alive.filter(p => p.id !== seer.id);
            if (targets.length > 0) {
                const target = targets[Math.floor(Math.random() * targets.length)];
                gameState.nightActions.seerCheck = {
                    target: target,
                    isWolf: target.role === '狼人' || target.role === '白狼王' || target.role === '狼美人'
                };
            }
        }
    }

    // 守卫守护
    const guard = alive.find(p => p.role === '守卫');
    if (guard) {
        if (guard.isUser) {
            // 用户是守卫 - 等待用户选择守护目标
            addMessage('system', '主持人', '你是守卫，请选择要守护的玩家');

            // 打开夜间行动模态框
            showNightActionModal('守卫：选择守护目标', 'guard-protect');
            gameState.resolveNightAction = null;

            await new Promise(resolve => {
                gameState.resolveNightAction = resolve;
            });
        } else {
            // AI守卫
            const targets = alive.filter(p => p.id !== guard.id);
            if (targets.length > 0) {
                gameState.nightActions.guardProtect = targets[Math.floor(Math.random() * targets.length)];
            }
        }
    }
}

function showWolfChatModal() {
    const modal = document.getElementById('wolf-chat-modal');
    modal.classList.add('show');
    // 清空狼人聊天记录显示
    document.getElementById('wolf-chat-messages').innerHTML = '';
}

async function runWolfDiscussion(aiWolves, targets) {
    const wolfOrder = [...aiWolves].map((wolf, index) => ({
        name: `狼人${index + 1}`,
        id: wolf.id,
        realName: wolf.name
    }));

    // 获取白天的公开讨论记录
    const dayHistory = gameState.messages.slice(-20).map(m => `${m.sender}: ${m.text}`).join('\n');

    // 记录开始讨论
    addWolfMessage('系统', '开始狼人团队讨论...');

    let discussionLog = '';

    // 讨论阶段
    for (let i = 0; i < wolfOrder.length; i++) {
        const speaker = wolfOrder[i];
        const wolf = aiWolves.find(w => w.id === speaker.id);

        const discussPrompt = `你是狼人${wolf.name}。你们狼人团队正在讨论要杀谁，请发表你的看法。

存活好人：${targets.map(t => t.name).join('、')}

【今天的公开讨论】（供你参考）
${dayHistory}

【狼人团队之前的讨论】
${discussionLog || '暂无'}

**注意：发言控制在30字以内，简短有力。最后说玩家名字。**`;

        const response = await callPlayerAI(wolf, discussPrompt);
        const targetName = parseName(response, targets.map(t => t.name));

        discussionLog += `\n${speaker.name}: ${response}`;
        addWolfMessage(speaker.name, response);

        // 等待发言间隔
        await new Promise(resolve => setTimeout(resolve, gameState.intervalSeconds * 500));
    }

    // 投票阶段
    addWolfMessage('系统', '讨论结束，开始投票...');

    const votes = {};
    for (let i = 0; i < wolfOrder.length; i++) {
        const speaker = wolfOrder[i];
        const wolf = aiWolves.find(w => w.id === speaker.id);

        const votePrompt = `你是狼人${wolf.name}。基于刚才的讨论，请投票决定要杀死的玩家。

存活好人：${targets.map(t => t.name).join('、')}

这是投票，直接说玩家名字，不要其他话。`;

        const response = await callPlayerAI(wolf, votePrompt);
        const targetName = parseName(response, targets.map(t => t.name));
        votes[targetName] = (votes[targetName] || 0) + 1;

        addWolfMessage(`${speaker.name}的投票`, targetName);

        // 等待投票间隔
        await new Promise(resolve => setTimeout(resolve, gameState.intervalSeconds * 300));
    }

    // 统计票数
    let maxVotes = 0;
    let killTarget = targets[0];
    Object.entries(votes).forEach(([name, count]) => {
        if (count > maxVotes) {
            maxVotes = count;
            killTarget = targets.find(t => t.name === name);
        }
    });

    gameState.nightActions.wolfKill = killTarget || targets[0];

    // 显示最终决定
    addWolfMessage('系统', `狼人团队决定今晚击杀：${gameState.nightActions.wolfKill.name}`);
}

function addWolfMessage(sender, text) {
    gameState.wolfMessages.push({
        sender: sender,
        text: text,
        time: new Date().toLocaleTimeString()
    });

    // 如果狼人聊天弹窗打开，实时显示
    const modal = document.getElementById('wolf-chat-modal');
    if (modal && modal.classList.contains('show')) {
        renderWolfMessages();
    }
}

function renderWolfMessages() {
    const container = document.getElementById('wolf-chat-messages');
    if (!container) return;

    container.innerHTML = gameState.wolfMessages.map(msg => {
        return `
            <div class="message wolf">
                <div class="message-sender">${msg.sender}</div>
                <div class="message-text">${msg.text}</div>
            </div>
        `;
    }).join('');

    container.scrollTop = container.scrollHeight;
}

function sendWolfMessage() {
    const input = document.getElementById('wolf-input');
    const text = input.value.trim();
    if (!text) return;

    addWolfMessage(gameState.userPlayer.name, text);
    input.value = '';

    // 如果正在等待用户发言
    if (gameState.waitingForWolfSpeak) {
        gameState.waitingForWolfSpeak = false;
        if (gameState.resolveWolfSpeak) {
            gameState.resolveWolfSpeak();
            gameState.resolveWolfSpeak = null;
        }
        return;
    }

    // 如果正在等待用户投票
    if (gameState.waitingForWolfVote) {
        // 解析投票目标
        const alive = gameState.players.filter(p => p.alive);
        const targets = alive.filter(p => p.role !== '狼人' && p.role !== '白狼王' && p.role !== '狼美人');
        const targetName = parseName(text, targets.map(t => t.name));
        const target = targets.find(t => t.name === targetName);

        if (target) {
            gameState.votes[gameState.userPlayer.id] = target.id;
            addWolfMessage(`${gameState.userPlayer.name}的投票`, target.name);
        } else {
            addWolfMessage('系统', '无效的投票，将随机选择');
            const randomTarget = targets[Math.floor(Math.random() * targets.length)];
            gameState.votes[gameState.userPlayer.id] = randomTarget.id;
            addWolfMessage(`${gameState.userPlayer.name}的投票`, randomTarget.name);
        }

        gameState.waitingForWolfVote = false;
        if (gameState.resolveWolfVote) {
            gameState.resolveWolfVote();
            gameState.resolveWolfVote = null;
        }
    }
}

// ==================== 白天阶段 ====================
function showDayAnnounce() {
    if (!checkGameRunning()) return;

    gameState.phase = PHASE.DAY_ANNOUNCE;
    closeAllModals();
    updatePhaseDisplay();

    let dead = [];
    const killed = gameState.nightActions.wolfKill;
    const guarded = gameState.nightActions.guardProtect;
    const wasSaved = gameState.nightActions.witchSave;

    // 检查被杀的是否被守卫保护
    if (killed && guarded && killed.id === guarded.id && !wasSaved) {
        // 被守护保护，不死
    } else if (killed && !wasSaved) {
        dead.push(killed);
    }

    // 女巫毒药
    if (gameState.nightActions.witchPoison) {
        dead.push(gameState.nightActions.witchPoison);
    }

    dead.forEach(p => {
        p.alive = false;
        gameState.deadPlayers.push(p);
    });

    if (dead.length === 0) {
        addMessage('system', '主持人', '============== 天亮了 ==============\n昨晚是平安夜，没有人死亡。');
    } else {
        addMessage('system', '主持人', `============== 天亮了 ==============\n昨晚死亡的有：${dead.map(p => p.name).join('、')}`);
    }

    renderPlayers();

    // 检查游戏是否结束
    if (checkWinCondition()) {
        return;
    }

    setTimeout(startDaySpeak, 2000);
}

function startDaySpeak() {
    if (!checkGameRunning()) return;

    gameState.phase = PHASE.DAY_SPEAK;
    updatePhaseDisplay();
    addMessage('system', '主持人', '============== 白天发言阶段 ==============');

    const alive = gameState.players.filter(p => p.alive);
    gameState.speakingOrder = [...alive];
    if (gameState.randomOrder) {
        shuffleArray(gameState.speakingOrder);
    }
    gameState.currentSpeakerIndex = 0;

    handleDaySpeak();
}

async function handleDaySpeak() {
    if (!checkGameRunning()) return;

    const alive = gameState.speakingOrder.filter(p => p.alive);

    if (gameState.currentSpeakerIndex >= alive.length) {
        handleVote();
        return;
    }

    const speaker = alive[gameState.currentSpeakerIndex];

    // 用户发言
    if (speaker.isUser) {
        addMessage('system', '主持人', `【发言】轮到你发言了`);
        enableInput(true, '发言');
        return;
    }

    // AI发言
    addMessage('system', '主持人', `【发言】${speaker.name} 正在发言...`);

    try {
        const prompt = buildDaySpeakPrompt(speaker, alive);
        const response = await callPlayerAI(speaker, prompt);
        const model = resolveModel(speaker.model);
        const displayModel = getDisplayModel(speaker.model, model);
        addMessage('ai', speaker.name, `${response} [${displayModel}]`);
    } catch (e) {
        addMessage('ai', speaker.name, '（发言失败）');
    }

    gameState.currentSpeakerIndex++;
    setTimeout(handleDaySpeak, gameState.intervalSeconds * 1000);
}

function buildDaySpeakPrompt(speaker, alive) {
    const history = gameState.messages.slice(-20).map(m => `${m.sender}: ${m.text}`).join('\n');
    let secretInfo = '';

    // 如果是预言家且已查验
    if (speaker.role === '预言家' && gameState.nightActions.seerCheck) {
        const check = gameState.nightActions.seerCheck;
        secretInfo = `\n（你昨晚查验了${check.target.name}，他是${check.isWolf ? '狼人' : '好人'}）`;
    }

    const isWolf = speaker.role === '狼人' || speaker.role === '白狼王' || speaker.role === '狼美人';

    return `${speaker.name}，你是${speaker.role}。
${speaker.description || ''}

存活玩家：${alive.map(p => p.name).join('、')}
死亡玩家：${gameState.deadPlayers.map(p => p.name).join('、') || '无'}
${secretInfo}

之前的发言：
${history}

${isWolf ? '请分析局势，进行发言，为团队找出有价值的目标，隐藏身份并干扰好人。' : '请分析局势，进行发言，分析谁是好人、谁是狼人。'}

**注意：发言控制在50字以内，简短有力。**`;
}

// ==================== 投票阶段 ====================
function handleVote() {
    if (!checkGameRunning()) return;

    gameState.phase = PHASE.DAY_VOTE;
    updatePhaseDisplay();
    addMessage('system', '主持人', '============== 发言结束，开始投票 ==============');

    gameState.votes = {};
    gameState.currentSpeakerIndex = 0;

    handleOneVote();
}

async function handleOneVote() {
    if (!checkGameRunning()) return;

    const alive = gameState.speakingOrder.filter(p => p.alive);

    if (gameState.currentSpeakerIndex >= alive.length) {
        await countVotes();
        return;
    }

    const voter = alive[gameState.currentSpeakerIndex];
    const targets = alive.filter(p => p.id !== voter.id);

    // 用户投票
    if (voter.isUser) {
        addMessage('system', '主持人', `【投票】轮到你投票了，请输入玩家名字`);
        enableInput(true, '投票');
        return;
    }

    // AI投票
    addMessage('system', '主持人', `【投票】${voter.name} 正在投票...`);

    try {
        const prompt = buildVotePrompt(voter, targets);
        const response = await callPlayerAI(voter, prompt);

        const targetName = parseName(response, targets.map(t => t.name));
        const target = targets.find(t => t.name === targetName) || targets[Math.floor(Math.random() * targets.length)];

        gameState.votes[voter.id] = target.id;
        addMessage('system', '主持人', `${voter.name} 投票给 ${target.name}`);
    } catch (e) {
        // 随机投票
        const target = targets[Math.floor(Math.random() * targets.length)];
        gameState.votes[voter.id] = target.id;
        addMessage('system', '主持人', `${voter.name} 投票给 ${target.name}`);
    }

    gameState.currentSpeakerIndex++;
    setTimeout(handleOneVote, gameState.intervalSeconds * 1000);
}

function buildVotePrompt(voter, targets) {
    const history = gameState.messages.slice(-15).map(m => `${m.sender}: ${m.text}`).join('\n');

    return `${voter.name}（${voter.role}），请投票。

存活玩家：${targets.map(p => p.name).join('、')}

之前的发言：
${history}

直接说玩家名字。`;
}

function parseName(text, names) {
    for (const name of names) {
        if (text.includes(name)) return name;
    }
    return names[0];
}

async function countVotes() {
    const voteCount = {};
    Object.values(gameState.votes).forEach(id => {
        voteCount[id] = (voteCount[id] || 0) + 1;
    });

    let result = '【投票结果】\n';
    gameState.speakingOrder.filter(p => p.alive).forEach(p => {
        result += `${p.name}: ${voteCount[p.id] || 0}票\n`;
    });

    addMessage('system', '主持人', result);

    let maxVotes = 0;
    let tied = [];
    Object.entries(voteCount).forEach(([id, count]) => {
        if (count > maxVotes) {
            maxVotes = count;
            tied = [id];
        } else if (count === maxVotes) {
            tied.push(id);
        }
    });

    if (tied.length === 1) {
        const eliminated = gameState.players.find(p => p.id === tied[0]);
        eliminated.alive = false;
        gameState.deadPlayers.push(eliminated);
        addMessage('system', '主持人', `${eliminated.name} 被投出，他的身份是 ${eliminated.role}`);
        renderPlayers();

        // 检查游戏是否结束
        if (checkWinCondition()) {
            return;
        }

        // 猎人处理
        if (eliminated.role === '猎人') {
            await handleHunterDeath(eliminated);
        }
    } else {
        addMessage('system', '主持人', '平票，进入下一晚');
    }

    if (gameState.isRunning) {
        setTimeout(() => {
            gameState.day++;
            startNightPhase();
        }, gameState.intervalSeconds * 1000);
    }
}

// 猎人死亡处理
async function handleHunterDeath(hunter) {
    const alive = gameState.players.filter(p => p.alive);
    if (alive.length <= 1) {
        addMessage('system', '主持人', `${hunter.name} 发动猎人技能，但没有可选目标`);
        return;
    }

    const targets = alive.filter(p => p.id !== hunter.id);

    addMessage('system', '主持人', `${hunter.name} 是猎人，正在选择要带走谁...`);

    if (targets.length > 0) {
        const prompt = `你是猎人${hunter.name}。你被投出了，现在要发动技能带走一名玩家。

存活玩家：${targets.map(t => t.name).join('、')}

请选择要带走的一名玩家，直接说玩家名字，不要其他话。`;

        try {
            const response = await callPlayerAI(hunter, prompt);
            const targetName = parseName(response, targets.map(t => t.name));
            const shot = targets.find(t => t.name === targetName) || targets[0];

            if (shot) {
                shot.alive = false;
                gameState.deadPlayers.push(shot);
                addMessage('system', '主持人', `${hunter.name} 发动猎人技能，带走了 ${shot.name}`);
            }
        } catch (e) {
            const shot = targets[Math.floor(Math.random() * targets.length)];
            if (shot) {
                shot.alive = false;
                gameState.deadPlayers.push(shot);
                addMessage('system', '主持人', `${hunter.name} 发动猎人技能，带走了 ${shot.name}`);
            }
        }
    }
}

// ==================== 胜负判定 ====================
function checkWinCondition() {
    const alive = gameState.players.filter(p => p.alive);
    const wolves = alive.filter(p => p.role === '狼人' || p.role === '白狼王' || p.role === '狼美人');
    const goods = alive.filter(p => p.role !== '狼人' && p.role !== '白狼王' && p.role !== '狼美人');

    if (wolves.length === 0) {
        endGame('好人胜利！所有狼人已被出局。', true);
        return true;
    } else if (wolves.length >= goods.length) {
        endGame('狼人胜利！好人已无法对抗狼人。', false);
        return true;
    }

    return false;
}

function endGame(message, userWins) {
    gameState.isRunning = false;
    gameState.phase = PHASE.GAME_END;
    updatePhaseDisplay();

    // 检查用户阵营
    const userIsWolf = gameState.userPlayer.role === '狼人' ||
                      gameState.userPlayer.role === '白狼王' ||
                      gameState.userPlayer.role === '狼美人';
    const finalWin = userIsWolf ? !userWins : userWins;

    const modal = document.getElementById('end-modal');
    const title = document.getElementById('end-title');
    const msg = document.getElementById('end-message');
    const roles = document.getElementById('end-roles');

    title.textContent = finalWin ? '🎉 胜利！' : '😢 失败';
    title.className = 'end-title ' + (finalWin ? 'win' : 'lose');
    msg.textContent = `${message}\n你的身份是：${gameState.userPlayer.role}`;

    // 根据阵营决定能看到什么
    // 狼人只能看到狼人队友，平民只能看到被杀/被投出的人
    let visibleRoles = [];
    if (userIsWolf) {
        // 狼人能看到所有狼人身份
        visibleRoles = gameState.players.filter(p => 
            p.role === '狼人' || p.role === '白狼王' || p.role === '狼美人'
        );
    } else {
        // 平民只能看到已死亡玩家的身份
        visibleRoles = gameState.players.filter(p => !p.alive);
    }

    if (visibleRoles.length === 0) {
        roles.innerHTML = '<p>游戏结束，你存活到了最后！但你无法看到其他存活玩家的身份。</p>';
    } else {
        roles.innerHTML = '<h4>你能看到的身份：</h4>' +
            visibleRoles.map(p =>
                `<p>${escapeHtml(p.name)} - ${p.role}</p>`
            ).join('');
    }

    modal.classList.add('show');
}

// ==================== 辅助函数 ====================
function checkGameRunning() {
    return gameState.isRunning !== false;
}

function enableInput(enabled, placeholder) {
    const input = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const actionArea = document.getElementById('action-area');
    const inputArea = document.getElementById('input-area');

    input.disabled = !enabled;
    sendBtn.disabled = !enabled;

    if (enabled) {
        inputArea.style.display = 'flex';
        actionArea.style.display = 'none';
        input.placeholder = placeholder;
        input.focus();
    }
}

function showRoleModal() {
    const modal = document.getElementById('role-modal');
    const icon = document.getElementById('role-icon');
    const name = document.getElementById('role-name');
    const desc = document.getElementById('role-desc');
    const secret = document.getElementById('role-secret');

    const roleIcon = ROLE_ICONS[gameState.userPlayer.role] || 'fa-user';
    icon.innerHTML = `<i class="fas ${roleIcon}"></i>`;
    name.textContent = gameState.userPlayer.role;

    const roleDescriptions = {
        '预言家': '每天晚上可以查验一名玩家是否是狼人',
        '女巫': '有一瓶解药和一瓶毒药，可以救人或杀人',
        '猎人': '被投票出局时可以开枪带走一名玩家',
        '守卫': '每天晚上可以守护一名玩家，防止被狼人杀害',
        '平民': '没有特殊能力，依靠推理找出狼人',
        '狼人': '每晚可以杀死一名玩家，目标是杀光所有好人',
        '白狼王': '特殊狼人，被投票出局时可以自爆带走一名玩家',
        '狼美人': '特殊狼人，每晚可以魅惑一名玩家，使其在白天无法投票'
    };

    desc.textContent = roleDescriptions[gameState.userPlayer.role] || '普通玩家';

    let secretText = '';
    if (gameState.userPlayer.role === '预言家' && gameState.nightActions.seerCheck) {
        const check = gameState.nightActions.seerCheck;
        secretText = `你昨晚查验了 ${check.target.name}，他是 ${check.isWolf ? '狼人' : '好人'}`;
    }
    secret.textContent = secretText || '暂无';

    modal.classList.add('show');
}

function closeAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('show');
    });
}

// ==================== AI 调用函数 ====================
async function callPlayerAI(player, prompt) {
    const model = resolveModel(player.model);
    try {
        const response = await fetch(`${player.endpoint}/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${player.apiKey}` },
            body: JSON.stringify({ model: model, messages: [{ role: 'user', content: prompt }], stream: false })
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        if (!data.choices || !data.choices[0] || !data.choices[0].message) {
            throw new Error('Invalid response format');
        }
        return data.choices[0].message.content;
    } catch (e) {
        console.error('AI调用失败:', e);
        // 返回备用响应
        const fallbackResponses = ['我觉得情况有点复杂', '需要再观察一下', '保持谨慎'];
        return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
